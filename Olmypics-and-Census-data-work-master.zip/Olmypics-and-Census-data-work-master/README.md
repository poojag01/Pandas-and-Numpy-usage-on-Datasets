I have done analysis on 2 datasets using python and tried to explore Machine Learning tools provided by Numpy and Pandas ( famous libraries of Python).

## This repository has 2 Parts : 


# Part 1

## All Time Olmypics Games Medals
This repository loads the olympics dataset (olympics.csv), which was derrived from the Wikipedia entry on [All Time Olympic Games Medals](https://en.wikipedia.org/wiki/All-time_Olympic_Games_medal_table), and does some basic data cleaning. 


# Part 2
## United States Census Bureau
For the next set of questions, we will be using census data from the [United States Census Bureau](http://www.census.gov).
Counties are political and geographic subdivisions of states in the United States.
This dataset contains population data for counties and states in the US from 2010 to 2015.
[ See this document](https://www2.census.gov/programs-surveys/popest/technical-documentation/file-layouts/2010-2015/co-est2015-alldata.pdf) for a description of the variable names.

( I have attached the files of data sets on which i have worked)

